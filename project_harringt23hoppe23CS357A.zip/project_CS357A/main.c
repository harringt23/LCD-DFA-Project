/* --COPYRIGHT--,BSD
 * Copyright (c) 2015, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 * --/COPYRIGHT--*/
//****************************************************************************
//
// main.c - MSP-EXP432P401R + Educational Boosterpack MkII - Temperature
//
//          Displays temperature measured by the TMP006 Infrared Thermopile
//          Contactless Temperature Sensor. The MSP432 communicates
//          with the sensor through I2C.
//
//****************************************************************************

#include <ti/devices/msp432p4xx/inc/msp.h>
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>
#include <ti/grlib/grlib.h>
#include "LcdDriver/Crystalfontz128x128_ST7735.h"
#include "LcdDriver/HAL_MSP_EXP432P401R_Crystalfontz128x128_ST7735.h"
#include <stdio.h>
#include <math.h>


/* TYPE DEFINITIONS */
// define a type for the state numbers
typedef enum {
	Q0,
	Q1,
	Q2,
	Q3,
	Q4,
	Q5,
	Q6,
	Q7
} state_num;

// define a global struct that holds values for the states
typedef struct State {
	// type of state
	state_num stn;

	// x coordinates
	int x;

	// y coordinates
	int y;

} state;

// initialize an array of states
state states[8] =
	{	{Q0, 15, 15},
		{Q1, 60, 15},
		{Q2, 105, 15},
		{Q3, 105, 60},
		{Q4, 15, 60},
		{Q5, 30, 105},
		{Q6, 60, 60},
		{Q7, 85, 105}
	};

//Transition table for
 //L = {w | w has an odd number of 'a's and starts/ends with the same letter}
 int transitions[8][2] = {
     //0,1
      {1,4}, //q0
      {3,2}, //q1
      {3,2}, //q2
      {1,3}, //q3
      {5,4}, //q4
      {7,6}, //q5
      {7,6}, //q6
      {5,7}  //q7
 };

 // initialize the current states
 int prevState = 0;
 int curState = 0;

 // initialize accept state - 0 false, 1 true
 int accept = 0;

 // initialize the radius sizes for the states
 int radius = 10;
 int current_radius = 13;

 // define the size of the string
#define string_size 8

// initialize a character array with the given string size
char string[string_size];


/* FUNCTION PROTOTYPES */
 void draw_transition(Graphics_Context* g_sContext);
 void unselect(int state, Graphics_Context* g_sContext);
 void select(int state, Graphics_Context* g_sContext);
 void transition_manage(int input, Graphics_Context* g_sContext);
 void draw_states(Graphics_Context* g_sContext, int current_state);
 void draw_lines(Graphics_Context* g_sContext);
 void init_graphics(Graphics_Context* g_sContext);
 void delay_init(void);
 void delay(uint32_t delay_us);

/****************************************************************************
 * DFA ON LCD - CS 357A
 *
 *
 * This C code to perform the following tasks on the LCD of BoosterPack
 * connected to MSP-432:
1. As soon as the program is executed, a timer starts.
2. When Button1 is pressed, a message appears on LCD stating
"The program started x seconds ago", where x is the number of seconds that have passed since the program started.
3. Once 20 seconds have passed from the start of the program
(whether the button was pushed or not) a message indicating "Time Out" shows up on the LCD.
 *
 * ERRORS: I cannot get the actual string to print, I tried adding a delay but that caused the timer to malfunction
 * and always print time out. However, I did get the count down working.
 *
 * @author Brynn Harrington
 * @author Emily Hoppe
 * @version November 22, 2021
 *
 *****************************************************************************/
/*
 * main
 *
 * This function instantiates the timer
 */
int main(void){
    // instantiate context for the graphics
    Graphics_Context g_sContext;

    // initialize the switches for the first button
    P5->SEL0 &= ~0x02; 	// set P5.1 as a simple GPIO
    P5->SEL1 &= ~0x02; 	// set P5.1 as a simple GPIO
    P5->DIR  &= ~0x02; 	// set P5.1 as inputs
    P5->REN  |=  0x02; 	// enable the resistors
    P5OUT    |= ~0x02; 	// set the resistors as pull-up

    // initialize the switches for the second button
	P3->SEL0 &= ~0x20; 	// set P3.5 as a simple GPIO
	P3->SEL1 &= ~0x20; 	// set P3.5 as a simple GPIO
	P3->DIR  &= ~0x20; 	// set P3.5 as inputs
	P3->REN  |=  0x20; 	// enable the resistors
	P5OUT    |= ~0x20; 	// set the resistors as pull-up

    // initialize the graph using the address of the graphics variable
    init_graphics(&g_sContext);

    // initialize the delay
    delay_init();

    // initialize the states starting at the start state
    draw_states(&g_sContext, 0);

    // iterate through the current count
   while(1)
   {
	  // transition from the current state based on an input 0 / button 1
	  if(~P5IN & 0X02) transition_manage(0, &g_sContext);


	  // transition from the current state based on an input 1 / button 2
	  if(~P3IN & 0X20) transition_manage(1, &g_sContext);
   }
}//main

//Unselect a state
void unselect(int state, Graphics_Context* g_sContext){
	Graphics_setForegroundColor(g_sContext, GRAPHICS_COLOR_BLACK);

	// draw circle with the graphics context and circle data
	Graphics_fillCircle(g_sContext, states[state].x, states[state].y, current_radius);

	Graphics_setForegroundColor(g_sContext, GRAPHICS_COLOR_LIGHT_STEEL_BLUE);

	// draw circle with the graphics context and circle data
	Graphics_fillCircle(g_sContext, states[state].x, states[state].y, radius);
}

//Light manager
void draw_transition(Graphics_Context* g_sContext){ //does the visual transition from state to state
    // turn off previous state
	unselect(prevState, g_sContext);

	// delay for visualization
	delay(200000);

	// redraw the states
	draw_states(g_sContext, curState);

}//draw_transition


/* transition_manage
 *
 * this function initializes the states and is called when the program is first ran
 * or an interrupt signal from a button is pressed is received
 *
 * parameter - g_sContext the current graphic context
 *
 */
void transition_manage(int input, Graphics_Context* g_sContext){ //Should execute the whole DFA on string (needs time delay)
    //update previous state
	prevState = curState;

    //Update current state
	if(input == 0){
	curState = transitions[curState][0];
	} else {
	curState = transitions[curState][1];
	}

	// check accepting
	if(curState == 1 || curState == 6){ //accepting states
	  accept = true;
	} else if((prevState == 1 && curState != 1 )||(prevState == 6 && curState != 6)) {
	  accept = false;
	}

	// update visual
	draw_transition(g_sContext);
}//transition_manage


/* draw_states
 *
 * this function initializes the states and is called when the program is first ran
 * or an interrupt signal from a button is pressed is received
 *
 */
void draw_states(Graphics_Context* g_sContext, int current_state)
{
	// draw the lines between states
    draw_lines(g_sContext);

    // determine if in accepting state
    if (accept) Graphics_setForegroundColor(g_sContext, 0x0024A455);
    else  Graphics_setForegroundColor(g_sContext, 0x00CD5C5C);

	// draw circle around selected state
	Graphics_fillCircle(g_sContext, states[current_state].x, states[current_state].y, current_radius);

	// set the font for the text to be displayed
	Graphics_setFont(g_sContext, &g_sFontCmsc12);

	// initialize all the states
	int st;
	for(st = 0; st < 8; st++){
		// set the color of the circle
		Graphics_setForegroundColor(g_sContext, GRAPHICS_COLOR_LIGHT_STEEL_BLUE);

		// get the x-coordinate and y-coordinate
		int x_coord = states[st].x;
		int y_coord = states[st].y;

		// draw state circle with the graphics context and circle data
		Graphics_fillCircle(g_sContext, x_coord, y_coord, radius);

		// set the background of the text to the color of circle
		Graphics_setBackgroundColor(g_sContext, GRAPHICS_COLOR_LIGHT_STEEL_BLUE);

		// set the font color to white
		Graphics_setForegroundColor(g_sContext, GRAPHICS_COLOR_BLACK);

		// print the string
		snprintf(string, string_size, "Q%d", st);

		// draw the string on the LCD
		Graphics_drawString(g_sContext, (int8_t*) string, -1, x_coord - (radius / 2) - 1, y_coord - (radius / 2) - 1, true);
	}
}//draw_states


/* draw_lines
 *
 * draws the lines between the states
 */
void draw_lines(Graphics_Context* g_sContext)
{
    Graphics_setForegroundColor(g_sContext, GRAPHICS_COLOR_LIGHT_STEEL_BLUE);

    //Draw line into start state
    Graphics_drawLine(g_sContext, 0, 0, 15, 15);

    //Draw q2 self-loop
    Graphics_drawLine(g_sContext, 123, 60, 105, 50);
    Graphics_drawLine(g_sContext, 123, 60, 105, 70);

    //Draw q3 self-loop
    Graphics_drawLine(g_sContext, 123, 15, 105, 5);
    Graphics_drawLine(g_sContext, 123, 15, 105, 25);

    //Draw q4 self-loop
    Graphics_drawLine(g_sContext, 33, 60, 15, 50);
    Graphics_drawLine(g_sContext, 33, 60, 15, 70);

    //Draw q6 self-loop
	Graphics_drawLine(g_sContext, 78, 60, 60, 50);
	Graphics_drawLine(g_sContext, 78, 60, 60, 70);

    //Draw q7 self-loop
	Graphics_drawLine(g_sContext, 103, 105, 85, 95);
	Graphics_drawLine(g_sContext, 103, 105, 85, 115);

    // t is the state transition out of
    int t;
    for(t = 0; t < 8; t++)
    {
        // t position
        int tx = states[t].x;
        int ty = states[t].y;

        // s is state we transition into
        int s = transitions[t][0];
        int sx = states[s].x;
        int sy = states[s].y;

        // draw line from tx ty to sx sy
        Graphics_drawLine(g_sContext, tx, ty, sx, sy);

        // s becomes the second state we transition into from t
        s = transitions[t][1];
        sx = states[s].x;
        sy = states[s].y;

        // draw line from tx ty to sx sy
        Graphics_drawLine(g_sContext, tx, ty, sx, sy);
    }
}//draw_lines


/* init_graphics
 *
 * initializes the graphics for the LCD instead of initializing in the main function
 *
 */
void init_graphics(Graphics_Context* g_sContext)
{
    // initialize the LCD
    Crystalfontz128x128_Init();

    // set the LCD orientation
    Crystalfontz128x128_SetOrientation(LCD_ORIENTATION_UP);

    // initialize context with the graphics
    Graphics_initContext(g_sContext, &g_sCrystalfontz128x128, &g_sCrystalfontz128x128_funcs);

    // set foreground and background colors
    Graphics_setForegroundColor(g_sContext, GRAPHICS_COLOR_WHITE);
    Graphics_setBackgroundColor(g_sContext, GRAPHICS_COLOR_BLACK);

    // clear the currently display context
    Graphics_clearDisplay(g_sContext);
}

/* delay_init
 *
 * initializes the timer mode (as periodic) and disables the interrupt
 *
 */
void delay_init(void)
{
// initialize the timer module with the base, pre-scaler, 32 bits, and periodic mode
    Timer32_initModule(TIMER32_0_BASE, TIMER32_PRESCALER_1,TIMER32_32BIT, TIMER32_PERIODIC_MODE);

    // disable the interrupt
    Timer32_disableInterrupt(TIMER32_0_BASE);
}//delay_init


/* delay
 *
 * starts the timer (with an initial value since in periodic mode) and gets the value
 *
 * @parameter duration_us - the desired duration in microseconds
 */
void delay(uint32_t duration_us)
{
	// halt the timer
    Timer32_haltTimer(TIMER32_0_BASE);

    // set the timer value since in periodic mode to 3 multiplied by the duration
    Timer32_setCount(TIMER32_0_BASE, 3 * duration_us);

    // start the timer
    Timer32_startTimer(TIMER32_0_BASE, true);

    // get the value of the timer while positive
    while(Timer32_getValue(TIMER32_0_BASE) > 0);
}//delay
